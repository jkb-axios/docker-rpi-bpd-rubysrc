require_relative '../inlinetest.rb'
InlineTest.loadtest__END__part('digest/hmac.rb')
