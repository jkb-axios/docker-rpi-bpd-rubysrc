class TestGem
  TEST_PLUGIN_LOAD = :loaded
end
